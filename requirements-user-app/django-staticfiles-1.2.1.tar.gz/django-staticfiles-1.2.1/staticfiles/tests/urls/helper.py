from django.conf.urls.defaults import *
from staticfiles.urls import staticfiles_urlpatterns

urlpatterns = staticfiles_urlpatterns()
