try:
    from actstream.signals import action
except:
    pass

__version__ = '0.6.0'
__author__ = 'Justin Quick <justquick@gmail.com>'
default_app_config = 'actstream.apps.ActstreamConfig'
