default_app_config = 'testapp_nested.apps.TestappNestedConfig'
