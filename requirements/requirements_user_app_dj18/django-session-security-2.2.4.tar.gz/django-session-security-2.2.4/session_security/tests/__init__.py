from .script import ScriptTestCase
from .views import ViewsTestCase
from .middleware import MiddlewareTestCase
