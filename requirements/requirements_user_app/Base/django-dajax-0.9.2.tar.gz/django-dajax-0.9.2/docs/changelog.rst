Changelog
=========

0.9.2
^^^^
* Fix unicode issues
* Fix Internet Explorer issues modifying element's innerHTML

0.9
^^^
* Move dajaxice core from dajaxice.core.Dajax to dajax.core
* Django 1.3 is now a requirement
* dajaxice 0.5 is now a requirement
* Static files are now located inside static instead of src

0.8.4
^^^^^
* Upgrade to dajaxice 0.1.3 (New Dajaxice.EXCEPTION)
* Dajax PEP8 naming style for addCSSClass and removeCSSClass
* Fixed some bugs in examples
* Fixed unicode problems

0.8.3
^^^^^
* General: New and cleaned setup.py

0.8.2
^^^^^
* General: Upgrade to dajaxice 0.1.1

0.8.0.1
^^^^^^^
* dajaxice released, now dajax use it as communication core
* cleaned all the code

0.7.5
^^^^^
* Added Dojo support
* Cleaned js files
* Ajax functions outside project folder now supported.
* Flickr in place editor example.

0.7.4.1
^^^^^^^
* Typo error importing ajax functions

0.7.4.0
^^^^^^^
* Typo error importing ajax functions
* Examples: Form validation using new utf-8 support.
* Examples: New deserialize method
* Examples: New DAJAX_CACHE_CONTROL usage in dajax.core.js view.
