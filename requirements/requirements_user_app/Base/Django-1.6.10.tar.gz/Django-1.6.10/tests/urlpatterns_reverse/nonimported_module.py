def view(request):
    """Stub view"""
    pass
