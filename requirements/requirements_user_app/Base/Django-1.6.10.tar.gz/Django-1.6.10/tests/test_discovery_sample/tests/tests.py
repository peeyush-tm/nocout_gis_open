from unittest import TestCase


class Test(TestCase):

    def test_sample(self):
        pass
