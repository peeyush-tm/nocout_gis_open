The List of Honored People
==========================

* Marc Abramowitz <marc@marc-abramowitz.com>
* Anton Baklanov <antonbaklanov@gmail.com>
* Johan Bergström <bugs@bergstroem.nu>
* Nikola Borisov <nikola.borisof@gmail.com>
* Rick Branson <rick@diodeware.com>
* Otto Bretz <otto.bretz@gmail.com>
* James Brown <jbrown@yelp.com>
* Ludvig Ericson <ludvig@lericson.se>
* Joe Hansche <jhansche@myyearbook.com>
* Keli Hlodversson <keli@hapti.co>
* ketralnis <ketralnis@reddit.com>
* Paweł Kowalak <pawel.kowalak@gmail.com>
* Hiroki Kumzaki <hiroki.kumazaki@gmail.com>
* Andrew McFague <amcfague@wgen.net>
* Remoun Metyas <remoun.metyas@gmail.com>
* Rudá Moura <ruda.moura@gmail.com>
* Muneyuki Noguchi <nogu.dev@gmail.com>
* Michael Schurter <schmichael@urbanairship.com>
* Radek Senfeld <rush@logic.cz>
* Noah Silas <noah@mahalo.com>
* Jari Sukanen <jari.sukanen@f-secure.com>
* John Watson <johnw@mahalo.com>
* Neil Williams <neil@reddit.com>
* Josh Wright <jshwright@gmail.com>
* Kelly Wong <kelly@bluejeans.com>

Thanks to `Blogg Esse AB`__ and `Send a Patch Jonken AB`__ for their support in
this open-source adventure, without these two companies this wouldn't have
happened.

__ http://blogg.se/
__ http://sendapatch.se/
