Andrei Antoukh / niwibe <https://github.com/niwibe>
Sean Bleier <http://github.com/sebleier>
Matt Dennewitz <http://github.com/blackbrrr>
Jannis Leidel <http://github.com/jezdez>
S. Angel / Twidi <http://github.com/twidi>
Noah Kantrowitz / coderanger <http://github.com/coderanger>
Martin Mahner / bartTC <http://github.com/bartTC>
Timothée Peignier / cyberdelia <https://github.com/cyberdelia>
Lior Sion / liorsion <https://github.com/liorsion>
Ales Zoulek / aleszoulek <https://github.com/aleszoulek>
James Aylett / jaylett <https://github.com/jaylett>
Todd Boland / boland <https://github.com/boland>
David Zderic / dzderic <https://github.com/dzderic>
Kirill Zaitsev / teferi <https://github.com/teferi>
