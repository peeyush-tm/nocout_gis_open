============================================
 celery.loaders
============================================

.. contents::
    :local:
.. currentmodule:: celery.loaders

.. automodule:: celery.loaders
    :members:
    :undoc-members:
