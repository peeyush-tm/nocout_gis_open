===========================================
 celery.backends.cache
===========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.cache

.. automodule:: celery.backends.cache
    :members:
    :undoc-members:
