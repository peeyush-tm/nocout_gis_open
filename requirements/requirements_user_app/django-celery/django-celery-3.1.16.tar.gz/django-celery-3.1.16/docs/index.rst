.. image:: http://cloud.github.com/downloads/ask/celery/celery_128.png

===============================
 Celery Integration for Django
===============================

Contents:

.. toctree::
    :maxdepth: 2

    introduction
    getting-started/index
    faq
    cookbook/index
    reference/index
    changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

