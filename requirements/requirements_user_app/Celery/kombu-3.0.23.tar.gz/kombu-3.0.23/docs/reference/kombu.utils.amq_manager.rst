====================================================
 Generic RabbitMQ manager - kombu.utils.amq_manager
====================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.amq_manager

.. automodule:: kombu.utils.amq_manager
    :members:
    :undoc-members:
