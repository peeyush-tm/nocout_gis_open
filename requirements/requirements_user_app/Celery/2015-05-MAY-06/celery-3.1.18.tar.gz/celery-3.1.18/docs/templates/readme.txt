=================================
 celery - Distributed Task Queue
=================================

.. image:: http://cloud.github.com/downloads/celery/celery/celery_128.png

.. include:: ../includes/introduction.txt

.. include:: ../includes/installation.txt

.. include:: ../includes/resources.txt


.. image:: https://d2weczhvl823v0.cloudfront.net/celery/celery/trend.png
    :alt: Bitdeli badge
    :target: https://bitdeli.com/free
