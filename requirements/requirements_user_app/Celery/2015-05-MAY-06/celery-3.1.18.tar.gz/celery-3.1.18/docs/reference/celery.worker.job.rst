=====================================
 celery.worker.job
=====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.job

.. automodule:: celery.worker.job
    :members:
    :undoc-members:
