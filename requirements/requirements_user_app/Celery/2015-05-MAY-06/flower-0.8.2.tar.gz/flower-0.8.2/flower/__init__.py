from __future__ import absolute_import

VERSION = (0, 8, 2)
__version__ = '.'.join(map(str, VERSION))
